import SwiftUI

enum AppTheme {
    // Verde claro, tomado del resplandor del logo
    static let accent = Color(
        uiColor: UIColor(red: 0.50, green: 0.95, blue: 0.20, alpha: 1.00)
    )
    // Color de texto/íconos para poner SOBRE el verde claro (el blanco no se lee)
    static let onAccent = Color(
        uiColor: UIColor(red: 0.02, green: 0.09, blue: 0.03, alpha: 1.00)
    )
    // Fondos oscuros con un tono verde muy suave
    static let pageBackground = Color(
        uiColor: UIColor(red: 0.012, green: 0.047, blue: 0.020, alpha: 1.00)
    )
    static let consoleBackground = Color(
        uiColor: UIColor(red: 0.027, green: 0.098, blue: 0.043, alpha: 1.00)
    )
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 20
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            Color(uiColor: .separator).opacity(0.22),
            lineWidth: 0.5
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(uiColor: .secondarySystemFill),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let logo = UIImage(named: "FoxRankLogo") {
                Image(uiImage: logo)
                    .resizable()
                    .scaledToFit()
                    .frame(width: size, height: size)
            } else {
                legacyIcon
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
            }
        }
        .accessibilityHidden(true)
    }

    @ViewBuilder
    private var legacyIcon: some View {
        if let icon = UIImage(named: "AppIcon60x60")
            ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
            ?? UIImage(named: "AppIcon") {
            Image(uiImage: icon)
                .resizable()
                .scaledToFill()
        } else {
            Image(systemName: "slider.horizontal.3")
                .font(.title2.weight(.semibold))
                .foregroundStyle(AppTheme.onAccent)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(AppTheme.accent)
        }
    }
}